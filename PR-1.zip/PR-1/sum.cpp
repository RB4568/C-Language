#include<iostream>
using namespace std;

class r
{
    public:	void bhk()
	{
		int a,b,sum;
	cout<<"enter the value of a: ";
	cin>>a;
	cout<<endl;
	cout<<"enter the value of b: ";
	cin>>b;
	cout<<endl;
	sum=a+b;
		cout<<"addition of a and b:"<<sum;
	}
	
};
main()
{
	r obj;
	
	obj.bhk();
	
}
