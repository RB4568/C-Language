#include<iostream>
using namespace std;


main()
{
    int a=10;
    char name[10]="rishit";
    
    cout<<"name="<<name<<endl;
    cout<<"id no:"<<a;
}
